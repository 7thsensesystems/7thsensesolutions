# 7th Sense Solutions — Website (self-contained build)

`index.html` is fully self-contained: the CSS, JavaScript, logo, favicon, and
your photo are all baked directly into the file. There are **no separate image,
CSS, or JS files to deploy** — which means nothing can go missing during upload.

## Deploy / redeploy to Netlify

**Drag & drop (recommended):**
1. Go to your site in Netlify → the **Deploys** tab.
2. Drag this entire `7th-sense-site` folder onto the deploy area
   ("Drag and drop your site output folder here").
3. Wait for the deploy to finish, then hard-refresh the site
   (Cmd/Ctrl + Shift + R) to clear the old cached version.

That's it. Because everything lives inside `index.html`, the logo, your photo,
and the corrected (no-red) styling will all appear.

**If you ever see the old version after deploying:** it's browser cache.
Hard-refresh, or open the site in a private/incognito window to confirm.

## Files
- `index.html` — the entire site, self-contained
- `404.html` — self-contained not-found page
- `og-image.png` — social share preview (link previews only)
- `netlify.toml`, `robots.txt`, `sitemap.xml` — config + SEO

## Editing later
Since styles and scripts are inlined, editing by hand is possible but fiddly.
Easiest path: send me the change and I'll regenerate the file. I keep the clean,
separated source files (styles.css, script.js, original logo/photo) on hand.

## Before launch — still to confirm
- Real stat numbers (funnels, automations, revenue) — only "600+ campaigns" and "9+ years" are verified so far.
- Testimonial wording + titles with Saguaro, Show Me Care, and Crossroads Donuts.
- Newsletter form wired to your Mailchimp/Kit action.
- Point the domain (7thsensesolutions.com) at the Netlify site; then the OG share image URL resolves.
